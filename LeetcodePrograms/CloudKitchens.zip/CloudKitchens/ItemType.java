package LeetcodePrograms.CloudKitchens;

public enum ItemType {
    Entree, Category, Option;
}
