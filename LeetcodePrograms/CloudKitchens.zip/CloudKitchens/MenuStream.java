package LeetcodePrograms.CloudKitchens;
// this is given
public interface MenuStream {
    String nextLine();
}
