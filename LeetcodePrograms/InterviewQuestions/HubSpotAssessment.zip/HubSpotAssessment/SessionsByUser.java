package LeetcodePrograms.InterviewQuestions.HubSpotAssessment;

import java.util.*;

public class SessionsByUser{
    Map<String,List<Session>> sessionsByUser;
    public SessionsByUser(Map<String, List<Session>> sessionsByUser) {
        this.sessionsByUser = sessionsByUser;
    }
}
